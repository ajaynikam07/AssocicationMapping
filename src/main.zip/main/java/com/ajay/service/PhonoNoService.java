package com.ajay.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ajay.entity.Person;
import com.ajay.entity.PhoneNo;
import com.ajay.repository.IPersonRepo;
import com.ajay.repository.IPhoneNoRepo;

@Service
public class PhonoNoService implements IAssociationMappingservice 
{
	@Autowired
	private IPersonRepo personRepo;
	@Autowired
	private IPhoneNoRepo phonoRepo;

	 @Override
	public String saveData(Person per) 
	{
		 
		 Person person = personRepo.save(per);
		 
		return "Person Object is save with id:"+person.getPid();
	}

	@Override
	public List<Person> allPersonData() 
	{
		return personRepo.findAll();
	}
	
	@Override
	public List<PhoneNo> allPhonoNO() 
	{
	
		return phonoRepo.findAll();
	}
}
